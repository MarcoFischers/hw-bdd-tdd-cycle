class DirectorToMovie < ActiveRecord::Migration
  def change
  end
end
